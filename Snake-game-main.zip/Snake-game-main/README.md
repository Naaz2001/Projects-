# Snake-game
This is a basic implementation of a Snake game using HTML, CSS, and JavaScript. It includes a game container, a snake, and a food item. The JavaScript code handles the movement of the snake, the generation of food, and the game logic
